"""Local filesystem connector - reference mode without data duplication.

This module provides LocalConnectorBackend, a connector that mounts an external local
folder into Nexus's virtual filesystem. Unlike CASLocalBackend (which uses CAS),
LocalConnectorBackend keeps files in their original location (SSOT - Single Source of Truth).

Key features:
- Zero data duplication (reference mode)
- Full indexing support (semantic search via sync_mount)
- Change detection via kernel OBSERVE (KernelDispatch)
- Direct read/write to original files
- L1-only caching (no L2 PostgreSQL needed since source is local)

Example:
    >>> nx.add_mount(
    ...     mount_point="/mnt/local",
    ...     backend_type="local_connector",
    ...     backend_config={"local_path": "C:/projects"},
    ... )
"""

import logging
from datetime import UTC
from pathlib import Path
from typing import TYPE_CHECKING, Any

from nexus.backends.base.backend import Backend, FileInfo
from nexus.backends.base.registry import (
    ArgType,
    ConnectionArg,
    register_connector,
)
from nexus.backends.wrappers.cache_mixin import CacheConnectorMixin
from nexus.contracts.backend_features import BackendFeature
from nexus.contracts.exceptions import BackendError, NexusFileNotFoundError
from nexus.core.hash_fast import hash_content
from nexus.core.object_store import WriteResult

if TYPE_CHECKING:
    from nexus.core.context import OperationContext

logger = logging.getLogger(__name__)


@register_connector(
    "local_connector",
    description="Mount local folder into Nexus (reference mode, no copy)",
    category="storage",
)
class LocalConnectorBackend(Backend, CacheConnectorMixin):
    """Local filesystem connector - reference mode without data duplication.

    Mounts an external local folder into Nexus VFS. Files remain in their
    original location (SSOT) - no content duplication to CAS.

    This is different from:
    - CASLocalBackend: Uses CAS for deduplication (copies content)

    LocalConnectorBackend is similar to GDriveConnector but for local filesystem:
    - Both use backend_path (not content_hash) for path-based access
    - Both support full indexing via sync_mount
    - LocalConnectorBackend doesn't need L2 cache (local disk IS the storage)

    Caching:
    - Uses L1-only mode (l1_only=True) - no L2 PostgreSQL
    - L1 cache stores metadata + disk_path pointing to original file
    - On L1 hit, content is read via mmap from original file
    - On L1 miss, reads file and populates L1 cache

    Storage structure:
        mount_point: /mnt/local-projects
        local_path:  C:\\Users\\user\\projects

        /mnt/local-projects/nexus/README.md
            → C:\\Users\\user\\projects\\nexus\\README.md

    Example:
        >>> backend = LocalConnectorBackend("C:/Users/user/projects")
        >>> content = backend.read_content("", context)  # Uses context.backend_path
    """

    _BACKEND_FEATURES = frozenset(
        {
            BackendFeature.DIRECTORY_LISTING,
            BackendFeature.CACHE_BULK_READ,
            BackendFeature.CACHE_SYNC,
        }
    )

    # Cache configuration: L1 only, no L2 (PostgreSQL)
    # Local disk is already fast, no need for persistent cache layer
    l1_only = True

    CONNECTION_ARGS: dict[str, ConnectionArg] = {
        "local_path": ConnectionArg(
            type=ArgType.PATH,
            description="Local folder path to mount",
            required=True,
        ),
        "readonly": ConnectionArg(
            type=ArgType.BOOLEAN,
            description="Mount as read-only",
            required=False,
            default=False,
        ),
        "follow_symlinks": ConnectionArg(
            type=ArgType.BOOLEAN,
            description="Follow symbolic links (default: True)",
            required=False,
            default=True,
        ),
    }

    def __init__(
        self,
        local_path: str | Path,
        readonly: bool = False,
        follow_symlinks: bool = True,
    ) -> None:
        """Initialize LocalConnectorBackend.

        Args:
            local_path: Local folder path to mount
            readonly: If True, write and delete operations will be rejected
            follow_symlinks: If True, follow symbolic links (default: True)

        Raises:
            BackendError: If local_path doesn't exist or is not a directory
        """
        super().__init__()
        self.local_path = Path(local_path).resolve()
        self.readonly = readonly
        self.follow_symlinks = follow_symlinks
        self._validate_path()

    def _validate_path(self) -> None:
        """Validate local path exists and is a directory.

        Raises:
            BackendError: If path doesn't exist or is not a directory
        """
        if not self.local_path.exists():
            raise BackendError(
                f"Local path does not exist: {self.local_path}",
                backend="local_connector",
                path=str(self.local_path),
            )
        if not self.local_path.is_dir():
            raise BackendError(
                f"Local path is not a directory: {self.local_path}",
                backend="local_connector",
                path=str(self.local_path),
            )

    @property
    def name(self) -> str:
        """Return the backend name."""
        return "local_connector"

    # =========================================================================
    # Path Translation
    # =========================================================================

    def _to_physical(self, virtual_path: str) -> Path:
        """Convert virtual path to physical path with symlink safety.

        Args:
            virtual_path: Path relative to mount point (e.g., "nexus/README.md")

        Returns:
            Absolute physical path on local filesystem

        Raises:
            BackendError: If resolved path escapes mount root (symlink attack)
        """
        clean = virtual_path.lstrip("/")
        physical = self.local_path / clean

        # Resolve symlinks if enabled
        if self.follow_symlinks:
            try:
                resolved = physical.resolve()
            except OSError:
                # Path doesn't exist yet, resolve parent
                resolved = physical.parent.resolve() / physical.name
        else:
            resolved = physical

        # Security: ensure path doesn't escape mount root
        try:
            resolved.relative_to(self.local_path)
        except ValueError as e:
            raise BackendError(
                f"Path escapes mount root: {virtual_path}",
                backend="local_connector",
                path=virtual_path,
            ) from e

        return resolved

    def get_physical_path(self, virtual_path: str) -> Path:
        """Get the physical path for file watching and L1 cache.

        This method is called by:
        - CacheConnectorMixin to get disk_path for L1 cache in l1_only mode

        Args:
            virtual_path: Path relative to mount point

        Returns:
            Absolute physical path on local filesystem
        """
        return self._to_physical(virtual_path)

    def get_watch_root(self) -> Path:
        """Get the root path to watch for changes.

        Returns:
            The local_path that was mounted
        """
        return self.local_path

    def get_file_info(
        self,
        path: str,
        context: "OperationContext | None" = None,
    ) -> "FileInfo":
        """
        Get file metadata for delta sync change detection (Issue #1127).

        Returns local file metadata including size, mtime, and inode-based version
        for efficient change detection during incremental sync.

        Args:
            path: Virtual file path (or backend_path from context)
            context: Operation context with optional backend_path

        Returns:
            FileInfo containing size, mtime, backend_version

        Raises:
            NexusFileNotFoundError: If file does not exist
            BackendError: On permission or OS errors
        """
        from datetime import datetime

        try:
            # Get backend path
            if context and context.backend_path:
                backend_path = context.backend_path
            else:
                backend_path = path.lstrip("/")

            physical = self._to_physical(backend_path)

            if not physical.exists():
                raise NexusFileNotFoundError(path)

            # Get file stats
            stat = physical.stat(follow_symlinks=self.follow_symlinks)

            size = stat.st_size
            mtime = datetime.fromtimestamp(stat.st_mtime, tz=UTC)

            # Build backend_version: inode + mtime_ns for robust change detection
            # This combination detects both content changes (mtime) and file replacement (inode)
            backend_version = f"{stat.st_ino}:{stat.st_mtime_ns}"

            return FileInfo(
                size=size,
                mtime=mtime,
                backend_version=backend_version,
                content_hash=None,  # Not computed to avoid reading file content
            )

        except NexusFileNotFoundError:
            raise
        except FileNotFoundError as e:
            raise NexusFileNotFoundError(path) from e
        except PermissionError as e:
            raise BackendError(f"Permission denied: {path} - {e}") from e
        except OSError as e:
            raise BackendError(f"Failed to get file info: {e}") from e

    # =========================================================================
    # Content Operations (with L1 Caching)
    # =========================================================================

    def read_content(
        self,
        content_id: str,
        context: "OperationContext | None" = None,
    ) -> bytes:
        """Read file content with L1 caching.

        For LocalConnectorBackend, content_hash is ignored - we use context.backend_path.

        Flow:
        1. Check L1 cache (TTL-based)
        2. If hit, return cached content (mmap from original file)
        3. If miss, read from disk and populate L1 cache

        Args:
            content_hash: Ignored (LocalConnectorBackend uses path-based access)
            context: Operation context with backend_path

        Returns:
            File content as bytes

        Raises:
            BackendError: If context/backend_path missing, permission denied, or OS error
            NexusFileNotFoundError: If file does not exist
        """
        if context is None or not context.backend_path:
            raise BackendError("LocalConnectorBackend requires context with backend_path")

        path = context.backend_path
        cache_path = context.virtual_path if context.virtual_path else path

        # Step 1: Check L1 cache
        if self._has_caching():
            try:
                cached = self._read_from_cache(cache_path, original=True)
                if cached and not cached.stale and cached.content_binary:
                    logger.info(f"[LocalConnectorBackend] L1 cache hit: {cache_path}")
                    return cached.content_binary
            except Exception as e:
                logger.debug("[CACHE] Cache read failed for %s: %s", cache_path, e)

        # Step 2: L1 miss - read from disk
        logger.debug(f"[LocalConnectorBackend] L1 cache miss, reading from disk: {path}")
        physical = self._to_physical(path)

        if not physical.exists():
            raise NexusFileNotFoundError(path)
        if not physical.is_file():
            raise BackendError(f"Not a file: {path}")

        try:
            content = physical.read_bytes()
        except PermissionError as e:
            raise BackendError(f"Permission denied: {path} - {e}") from e
        except OSError as e:
            raise BackendError(f"Read error: {e}") from e

        # Step 3: Populate L1 cache for future reads
        if self._has_caching():
            try:
                zone_id = getattr(context, "zone_id", None)
                self._write_to_cache(
                    path=cache_path,
                    content=content,
                    zone_id=zone_id,
                )
            except Exception as e:
                logger.debug("[CACHE] Cache write failed for %s: %s", cache_path, e)

        return content

    def write_content(
        self,
        content: bytes,
        content_id: str = "",
        *,
        offset: int = 0,
        context: "OperationContext | None" = None,
    ) -> WriteResult:
        """Write content directly to local path.

        Unlike CAS-based backends, this writes directly to the file.
        Returns WriteResult with content hash and size.
        Invalidates L1 cache after write.

        Args:
            content: Bytes to write
            context: Operation context with backend_path

        Returns:
            WriteResult with content_hash (SHA-256) and size

        Raises:
            BackendError: If read-only, missing path, permission denied, or OS error
        """
        if self.readonly:
            raise BackendError("Backend is read-only")

        # Get path from context
        write_path = context.backend_path if context else None

        if write_path is None:
            raise BackendError("Path required for local_connector backend")

        physical = self._to_physical(write_path)

        # Offset write: read-splice-write (Issue #1395)
        if offset > 0:
            try:
                old_data = physical.read_bytes() if physical.exists() else b""
            except OSError:
                old_data = b""
            if offset > len(old_data):
                old_data = old_data + b"\x00" * (offset - len(old_data))
            content = old_data[:offset] + content + old_data[offset + len(content) :]

        try:
            physical.parent.mkdir(parents=True, exist_ok=True)
            physical.write_bytes(content)

            # Invalidate/update L1 cache
            cache_path = context.virtual_path if context and context.virtual_path else write_path
            if self._has_caching():
                try:
                    zone_id = getattr(context, "zone_id", None) if context else None
                    self._write_to_cache(
                        path=cache_path,
                        content=content,
                        zone_id=zone_id,
                    )
                except Exception as e:
                    logger.debug("[CACHE] Cache write failed for %s: %s", cache_path, e)

            # Return content hash and size for consistency
            content_hash = hash_content(content)
            return WriteResult(content_id=content_hash, version=content_hash, size=len(content))
        except PermissionError as e:
            raise BackendError(f"Permission denied: {write_path} - {e}") from e
        except OSError as e:
            raise BackendError(f"Write error: {e}") from e

    # =========================================================================
    # Directory Operations
    # =========================================================================

    def list_dir(
        self,
        path: str,
        context: "OperationContext | None" = None,
    ) -> list[str]:
        """List directory contents.

        Args:
            path: Virtual path relative to mount point
            context: Operation context (unused for local connector)

        Returns:
            List of entry names in the directory
        """
        physical = self._to_physical(path)

        if not physical.exists() or not physical.is_dir():
            return []

        try:
            return sorted(item.name for item in physical.iterdir())
        except (PermissionError, OSError):
            return []

    def list_dir_detailed(
        self,
        path: str = "",
        context: "OperationContext | None" = None,
    ) -> list[dict[str, Any]]:
        """List directory contents with detailed metadata.

        Args:
            path: Virtual path relative to mount point (default: root)
            context: Operation context (unused for local connector)

        Returns:
            List of entry dicts with name, type, size, modified.

        Raises:
            NexusFileNotFoundError: If directory does not exist.
            BackendError: If path is not a directory, permission denied, or OS error.
        """
        physical = self._to_physical(path)

        if not physical.exists():
            raise NexusFileNotFoundError(path, message=f"Directory not found: {path}")
        if not physical.is_dir():
            raise BackendError(f"Not a directory: {path}", backend="local_connector", path=path)

        try:
            entries = []
            for item in physical.iterdir():
                try:
                    stat = item.stat(follow_symlinks=self.follow_symlinks)
                    is_dir = item.is_dir()
                    entry = {
                        "name": item.name,
                        "type": "directory" if is_dir else "file",
                        "size": stat.st_size if not is_dir else 0,
                        "modified": stat.st_mtime,
                    }
                    entries.append(entry)
                except OSError:
                    # Skip entries we can't stat (broken symlinks, permission issues)
                    logger.debug(f"Skipping unreadable entry: {item}")
                    continue
            return entries
        except PermissionError as e:
            raise BackendError(f"Permission denied: {path} - {e}") from e
        except OSError as e:
            raise BackendError(f"List error: {e}") from e

    def exists(
        self,
        path: str,
        context: "OperationContext | None" = None,
    ) -> bool:
        """Check if path exists.

        Args:
            path: Virtual path relative to mount point
            context: Operation context (unused)

        Returns:
            True if path exists, False otherwise
        """
        try:
            return self._to_physical(path).exists()
        except BackendError:
            # Path escapes mount root
            return False

    def is_dir(
        self,
        path: str,
        context: "OperationContext | None" = None,
    ) -> bool:
        """Check if path is a directory.

        Args:
            path: Virtual path relative to mount point
            context: Operation context (unused)

        Returns:
            True if path is a directory, False otherwise
        """
        try:
            return self._to_physical(path).is_dir()
        except BackendError:
            return False

    def delete(
        self,
        path: str,
        context: "OperationContext | None" = None,
    ) -> None:
        """Delete file or empty directory.

        Args:
            path: Virtual path relative to mount point
            context: Operation context (unused)

        Raises:
            BackendError: If read-only, permission denied, or OS error.
            NexusFileNotFoundError: If path does not exist.
        """
        if self.readonly:
            raise BackendError("Backend is read-only", backend="local_connector", path=path)

        physical = self._to_physical(path)

        try:
            if physical.is_file():
                physical.unlink()
            elif physical.is_dir():
                physical.rmdir()  # Only empty directories
            else:
                raise NexusFileNotFoundError(path, message=f"Path not found: {path}")
        except NexusFileNotFoundError:
            raise
        except PermissionError as e:
            raise BackendError(f"Permission denied: {path} - {e}") from e
        except OSError as e:
            raise BackendError(f"Delete error: {e}") from e

    # =========================================================================
    # Backend Interface Methods (for Backend abstract base class)
    # =========================================================================

    def delete_content(
        self,
        content_id: str,
        context: "OperationContext | None" = None,
    ) -> None:
        """Delete content by hash - not supported for local_connector.

        LocalConnectorBackend uses path-based access, not content-hash based.
        This method exists for Backend interface compatibility.

        Raises:
            BackendError: Always (hash-based deletion not supported)
        """
        raise BackendError(
            "delete_content by hash not supported for local_connector. Use delete(path) instead."
        )

    def content_exists(
        self,
        content_id: str,
        context: "OperationContext | None" = None,
    ) -> bool:
        """Check if content exists by hash - not supported for local_connector."""
        return False

    def get_content_size(
        self,
        content_id: str,
        context: "OperationContext | None" = None,
    ) -> int:
        """Get content size by hash - not supported for local_connector.

        Raises:
            BackendError: Always (hash-based size lookup not supported)
        """
        raise BackendError("get_content_size by hash not supported for local_connector")

    def mkdir(
        self,
        path: str,
        parents: bool = False,
        exist_ok: bool = False,
        context: "OperationContext | None" = None,
    ) -> None:
        """Create a directory.

        Args:
            path: Virtual path relative to mount point
            parents: Create parent directories if needed (always True for local_connector)
            exist_ok: Don't error if directory exists (always True for local_connector)
            context: Operation context (unused)

        Raises:
            BackendError: If read-only, permission denied, or OS error
        """
        if self.readonly:
            raise BackendError("Backend is read-only")

        physical = self._to_physical(path)

        try:
            # Always use parents=True, exist_ok=True for simplicity
            physical.mkdir(parents=True, exist_ok=True)
        except PermissionError as e:
            raise BackendError(f"Permission denied: {path} - {e}") from e
        except OSError as e:
            raise BackendError(f"Mkdir error: {e}") from e

    def rmdir(
        self,
        path: str,
        recursive: bool = False,
        context: "OperationContext | None" = None,
    ) -> None:
        """Remove a directory.

        Args:
            path: Virtual path relative to mount point
            recursive: If True, remove directory and contents (not supported)
            context: Operation context (unused)

        Raises:
            BackendError: If recursive, read-only, permission denied, not a directory, or OS error
            NexusFileNotFoundError: If directory does not exist
        """
        if recursive:
            raise BackendError("Recursive rmdir not supported for safety")
        if self.readonly:
            raise BackendError("Backend is read-only")

        physical = self._to_physical(path)

        try:
            if physical.is_dir():
                physical.rmdir()
            else:
                raise BackendError(f"Not a directory: {path}")
        except FileNotFoundError as e:
            raise NexusFileNotFoundError(path) from e
        except PermissionError as e:
            raise BackendError(f"Permission denied: {path} - {e}") from e
        except BackendError:
            raise
        except OSError as e:
            raise BackendError(f"Rmdir error: {e}") from e

    def is_directory(
        self,
        path: str,
        context: "OperationContext | None" = None,
    ) -> bool:
        """Check if path is a directory."""
        return self.is_dir(path, context)

    def rename(
        self,
        old_path: str,
        new_path: str,
        context: "OperationContext | None" = None,
    ) -> None:
        """Rename/move a file or directory.

        Args:
            old_path: Current virtual path
            new_path: New virtual path
            context: Operation context (unused)

        Raises:
            BackendError: If read-only, permission denied, or OS error.
            NexusFileNotFoundError: If source path does not exist.
        """
        if self.readonly:
            raise BackendError("Backend is read-only", backend="local_connector", path=old_path)

        old_physical = self._to_physical(old_path)
        new_physical = self._to_physical(new_path)

        if not old_physical.exists():
            raise NexusFileNotFoundError(old_path, message=f"Source not found: {old_path}")

        try:
            # Create parent directories for destination if needed
            new_physical.parent.mkdir(parents=True, exist_ok=True)
            old_physical.rename(new_physical)
        except PermissionError as e:
            raise BackendError(f"Permission denied: {e}") from e
        except OSError as e:
            raise BackendError(f"Rename error: {e}") from e

    def stat(
        self,
        path: str,
        context: "OperationContext | None" = None,
    ) -> dict[str, Any]:
        """Get file or directory metadata.

        Args:
            path: Virtual path relative to mount point
            context: Operation context (unused)

        Returns:
            Dict with size, mtime, ctime, atime, is_dir, is_file, is_symlink, mode.

        Raises:
            NexusFileNotFoundError: If path does not exist.
            BackendError: If permission denied or OS error.
        """
        physical = self._to_physical(path)

        if not physical.exists():
            raise NexusFileNotFoundError(path, message=f"Path not found: {path}")

        try:
            st = physical.stat(follow_symlinks=self.follow_symlinks)
            return {
                "size": st.st_size,
                "mtime": st.st_mtime,
                "ctime": st.st_ctime,
                "atime": st.st_atime,
                "is_dir": physical.is_dir(),
                "is_file": physical.is_file(),
                "is_symlink": physical.is_symlink(),
                "mode": st.st_mode,
            }
        except PermissionError as e:
            raise BackendError(f"Permission denied: {path} - {e}") from e
        except OSError as e:
            raise BackendError(f"Stat error: {e}") from e

    def glob(
        self,
        pattern: str,
        context: "OperationContext | None" = None,
    ) -> list[str]:
        """Find files matching a glob pattern.

        Args:
            pattern: Glob pattern (e.g., "*.txt", "**/*.py")
            context: Operation context (unused)

        Returns:
            List of matching paths (relative to mount).

        Raises:
            BackendError: If permission denied or OS error.
        """
        try:
            matches = []
            for match in self.local_path.glob(pattern):
                # Security: ensure match is within mount root
                try:
                    rel_path = match.relative_to(self.local_path)
                    matches.append(str(rel_path).replace("\\", "/"))
                except ValueError:
                    # Path escapes mount root (shouldn't happen with glob)
                    continue
            return sorted(matches)
        except PermissionError as e:
            raise BackendError(f"Permission denied: {e}") from e
        except OSError as e:
            raise BackendError(f"Glob error: {e}") from e
