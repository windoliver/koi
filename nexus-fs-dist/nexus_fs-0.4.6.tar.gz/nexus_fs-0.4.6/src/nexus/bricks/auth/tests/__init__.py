"""Auth brick tests."""
