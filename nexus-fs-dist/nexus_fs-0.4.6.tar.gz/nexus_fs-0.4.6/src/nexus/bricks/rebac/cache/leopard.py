"""Leopard-style Transitive Group Closure Index

Implements pre-computed transitive group memberships for O(1) lookups,
based on Google Zanzibar's Leopard index (Section 2.4.2).

Performance:
    - 5-level nested group check: ~50ms -> ~1ms (50x faster)
    - 10-level nested group check: ~200ms -> ~1ms (200x faster)

Trade-offs:
    - Write latency: 2-5x slower (closure update)
    - Storage: O(members x groups)
    - Consistency: Eventual (async update option available)

Related: Issue #692
"""

import logging
import threading
import time
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

try:
    from cachebox import TTLCache as RustTTLCache
except ImportError:
    RustTTLCache = None  # type: ignore[assignment,misc]

try:
    from fastbloom_rs import BloomFilter
except ImportError:
    BloomFilter = None  # noqa: N816 — optional Rust dependency

if TYPE_CHECKING:
    from sqlalchemy.engine import Connection, Engine

logger = logging.getLogger(__name__)

# Relations that represent group membership (can be extended)
MEMBERSHIP_RELATIONS = frozenset({"member-of", "member", "belongs-to"})

# Entity types that can contain members (groups)
GROUP_ENTITY_TYPES = frozenset({"group", "team", "organization", "zone"})


@dataclass
class ClosureEntry:
    """A single entry in the transitive closure."""

    member_type: str
    member_id: str
    group_type: str
    group_id: str
    zone_id: str
    depth: int
    updated_at: datetime = field(default_factory=lambda: datetime.now(UTC))


class LeopardCache:
    """In-memory cache for transitive group closure.

    Provides O(1) lookups for "what groups does member X belong to?"

    Thread-safe implementation using RLock.
    """

    def __init__(self, max_size: int = 100_000, ttl_seconds: float = 3600.0):
        """Initialize the Leopard cache.

        Args:
            max_size: Maximum number of (member -> groups) mappings to cache
            ttl_seconds: Time-to-live in seconds for cached entries (default: 1h).
                Entries older than this are evicted on access to prevent serving
                stale group memberships indefinitely.
        """
        self._max_size = max_size
        self._ttl_seconds = ttl_seconds
        self._lock = threading.RLock()

        # Issue #3192 decision 16C: Use Rust-backed TTLCache for high-contention
        # member lookups when available. Falls back to manual dict + TTL checking.
        self._use_rust_cache = RustTTLCache is not None

        # member (type, id, zone) -> set of (group_type, group_id)
        # cachebox.TTLCache is API-compatible with dict for get/set/pop/clear.
        self._member_to_groups: dict[tuple[str, str, str], set[tuple[str, str]]]
        if self._use_rust_cache:
            self._member_to_groups = RustTTLCache(maxsize=max_size, ttl=ttl_seconds)  # type: ignore[assignment]
        else:
            self._member_to_groups = {}

        # group (type, id, zone) -> set of (member_type, member_id)
        # Used for invalidation when group membership changes.
        # Kept as a plain dict — low contention, invalidation-only path.
        self._group_to_members: dict[tuple[str, str, str], set[tuple[str, str]]] = {}

        # LRU / TTL tracking — only needed when NOT using cachebox
        # (cachebox handles TTL + maxsize eviction internally).
        if not self._use_rust_cache:
            self._access_times: dict[tuple[str, str, str], float] = {}
            self._insert_times: dict[tuple[str, str, str], float] = {}

        # BloomFilter pre-gate for fast negative membership checks (Issue #3192)
        self._bloom: BloomFilter | None = None
        self._bloom_capacity = max_size
        self._bloom_fpp = 0.01
        self._bloom_rejects = 0
        self._bloom_passes = 0
        if BloomFilter is not None:
            self._bloom = BloomFilter(self._bloom_capacity, self._bloom_fpp)

        # Recursion guard for eviction (see Issue #3192, decision 8C)
        self._evicting: bool = False

    def get_transitive_groups(
        self, member_type: str, member_id: str, zone_id: str
    ) -> set[tuple[str, str]] | None:
        """Get all groups a member transitively belongs to.

        Args:
            member_type: Type of member (e.g., "user", "agent")
            member_id: ID of member
            zone_id: Zone ID

        Returns:
            Set of (group_type, group_id) tuples, or None if not cached
        """
        key = (member_type, member_id, zone_id)
        with self._lock:
            # BloomFilter pre-gate: fast rejection for unknown members
            if self._bloom is not None:
                key_str = f"{member_type}:{member_id}:{zone_id}"
                if key_str not in self._bloom:
                    self._bloom_rejects += 1
                    return None
                self._bloom_passes += 1

            if self._use_rust_cache:
                # cachebox TTLCache handles TTL expiry and LRU eviction internally
                result = self._member_to_groups.get(key)
                if result is not None:
                    return result.copy()
                return None

            # Fallback: manual dict with TTL checking
            if key in self._member_to_groups:
                # TTL eviction: discard entries older than ttl_seconds
                insert_time = self._insert_times.get(key, 0.0)
                if time.time() - insert_time > self._ttl_seconds:
                    self._member_to_groups.pop(key, None)
                    self._access_times.pop(key, None)
                    self._insert_times.pop(key, None)
                    return None
                self._access_times[key] = time.time()
                return self._member_to_groups[key].copy()
            return None

    def set_transitive_groups(
        self,
        member_type: str,
        member_id: str,
        zone_id: str,
        groups: set[tuple[str, str]],
    ) -> None:
        """Cache transitive groups for a member.

        Args:
            member_type: Type of member
            member_id: ID of member
            zone_id: Zone ID
            groups: Set of (group_type, group_id) tuples
        """
        key = (member_type, member_id, zone_id)
        with self._lock:
            # Update member -> groups mapping
            old_groups = self._member_to_groups.get(key, set()) or set()

            if self._use_rust_cache:
                # cachebox handles maxsize eviction + TTL internally
                self._member_to_groups[key] = groups.copy()
            else:
                # Fallback: manual eviction
                if (
                    len(self._member_to_groups) >= self._max_size
                    and key not in self._member_to_groups
                ):
                    self._evict_lru()
                self._member_to_groups[key] = groups.copy()
                now = time.time()
                self._access_times[key] = now
                self._insert_times[key] = now

            # Update bloom filter
            if self._bloom is not None:
                key_str = f"{member_type}:{member_id}:{zone_id}"
                self._bloom.add(key_str)

            # Update reverse mapping (group -> members)
            for group_type, group_id in old_groups - groups:
                group_key = (group_type, group_id, zone_id)
                if group_key in self._group_to_members:
                    self._group_to_members[group_key].discard((member_type, member_id))

            for group_type, group_id in groups:
                group_key = (group_type, group_id, zone_id)
                if group_key not in self._group_to_members:
                    self._group_to_members[group_key] = set()
                self._group_to_members[group_key].add((member_type, member_id))

    def invalidate_member(self, member_type: str, member_id: str, zone_id: str) -> None:
        """Invalidate cache for a specific member.

        Args:
            member_type: Type of member
            member_id: ID of member
            zone_id: Zone ID
        """
        key = (member_type, member_id, zone_id)
        with self._lock:
            if key in self._member_to_groups:
                groups = self._member_to_groups.pop(key)
                if not self._use_rust_cache:
                    self._access_times.pop(key, None)
                    self._insert_times.pop(key, None)

                # Clean up reverse mapping
                for group_type, group_id in groups:
                    group_key = (group_type, group_id, zone_id)
                    if group_key in self._group_to_members:
                        self._group_to_members[group_key].discard((member_type, member_id))

    def invalidate_group(self, group_type: str, group_id: str, zone_id: str) -> None:
        """Invalidate cache for all members of a group.

        Called when group membership changes.

        Args:
            group_type: Type of group
            group_id: ID of group
            zone_id: Zone ID
        """
        group_key = (group_type, group_id, zone_id)
        with self._lock:
            members = self._group_to_members.pop(group_key, set())
            for member_type, member_id in members:
                member_key = (member_type, member_id, zone_id)
                self._member_to_groups.pop(member_key, None)
                if not self._use_rust_cache:
                    self._access_times.pop(member_key, None)
                    self._insert_times.pop(member_key, None)

    def invalidate_zone(self, zone_id: str) -> None:
        """Invalidate all cache entries for a zone.

        Args:
            zone_id: Zone ID
        """
        with self._lock:
            keys_to_remove = [k for k in self._member_to_groups if k[2] == zone_id]
            for key in keys_to_remove:
                self._member_to_groups.pop(key, None)
                if not self._use_rust_cache:
                    self._access_times.pop(key, None)
                    self._insert_times.pop(key, None)

            group_keys_to_remove = [k for k in self._group_to_members if k[2] == zone_id]
            for key in group_keys_to_remove:
                self._group_to_members.pop(key, None)

    def clear(self) -> None:
        """Clear all cached data."""
        with self._lock:
            self._member_to_groups.clear()
            self._group_to_members.clear()
            if not self._use_rust_cache:
                self._access_times.clear()
                self._insert_times.clear()
            if self._bloom is not None and BloomFilter is not None:
                self._bloom = BloomFilter(self._bloom_capacity, self._bloom_fpp)

    def _evict_lru(self) -> None:
        """Evict least recently used entries (must hold lock).

        No-op when using cachebox (eviction is handled internally).
        """
        if self._use_rust_cache:
            return
        if self._evicting or not self._access_times:
            return

        self._evicting = True
        try:
            num_to_evict = max(1, len(self._access_times) // 10)
            sorted_keys = sorted(self._access_times.items(), key=lambda x: x[1])

            for key, _ in sorted_keys[:num_to_evict]:
                # Inline the invalidation instead of calling invalidate_member()
                # to avoid re-acquiring the lock and potential recursion
                if key in self._member_to_groups:
                    groups = self._member_to_groups.pop(key)
                    self._access_times.pop(key, None)
                    self._insert_times.pop(key, None)
                    for group_type, group_id in groups:
                        group_key = (group_type, group_id, key[2])
                        if group_key in self._group_to_members:
                            self._group_to_members[group_key].discard((key[0], key[1]))
        finally:
            self._evicting = False

    @property
    def size(self) -> int:
        """Return current cache size."""
        with self._lock:
            return len(self._member_to_groups)


class LeopardIndex:
    """Leopard-style transitive closure index.

    Maintains pre-computed group memberships in both database and memory
    for ultra-fast permission checks.
    """

    def __init__(
        self,
        engine: "Engine",
        cache_enabled: bool = True,
        cache_max_size: int = 100_000,
        *,
        is_postgresql: bool = False,
    ):
        """Initialize the Leopard index.

        Args:
            engine: SQLAlchemy database engine
            cache_enabled: Whether to enable in-memory caching
            cache_max_size: Maximum entries in memory cache
            is_postgresql: Whether the database is PostgreSQL (config-time flag).
        """
        self._engine = engine
        self._cache_enabled = cache_enabled
        self._cache = LeopardCache(max_size=cache_max_size) if cache_enabled else None
        self._is_postgresql = is_postgresql

    @property
    def _now_sql(self) -> str:
        """Return SQL for current timestamp based on database type."""
        return "NOW()" if self._is_postgresql else "datetime('now')"

    def get_transitive_groups(
        self,
        member_type: str,
        member_id: str,
        zone_id: str,
        conn: "Connection | None" = None,
    ) -> set[tuple[str, str]]:
        """Get all groups a member transitively belongs to.

        First checks in-memory cache, then falls back to database.

        Args:
            member_type: Type of member (e.g., "user", "agent")
            member_id: ID of member
            zone_id: Zone ID
            conn: Optional existing database connection

        Returns:
            Set of (group_type, group_id) tuples
        """
        # Check cache first
        if self._cache:
            cached = self._cache.get_transitive_groups(member_type, member_id, zone_id)
            if cached is not None:
                if logger.isEnabledFor(logging.DEBUG):
                    logger.debug(
                        f"[LEOPARD] Cache hit for {member_type}:{member_id} -> {len(cached)} groups"
                    )
                return cached

        # Query database
        groups = self._fetch_transitive_groups_from_db(member_type, member_id, zone_id, conn)

        # Update cache
        if self._cache:
            self._cache.set_transitive_groups(member_type, member_id, zone_id, groups)
            if logger.isEnabledFor(logging.DEBUG):
                logger.debug(f"[LEOPARD] Cached {member_type}:{member_id} -> {len(groups)} groups")

        return groups

    def _fetch_transitive_groups_from_db(
        self,
        member_type: str,
        member_id: str,
        zone_id: str,
        conn: "Connection | None" = None,
    ) -> set[tuple[str, str]]:
        """Fetch transitive groups from database.

        Args:
            member_type: Type of member
            member_id: ID of member
            zone_id: Zone ID
            conn: Optional existing database connection

        Returns:
            Set of (group_type, group_id) tuples
        """
        from sqlalchemy import text

        query = text("""
            SELECT group_type, group_id
            FROM rebac_group_closure
            WHERE member_type = :member_type
              AND member_id = :member_id
              AND zone_id = :zone_id
        """)

        params = {
            "member_type": member_type,
            "member_id": member_id,
            "zone_id": zone_id,
        }

        groups: set[tuple[str, str]] = set()

        def execute_query(connection: "Connection") -> None:
            result = connection.execute(query, params)
            for row in result:
                groups.add((row.group_type, row.group_id))

        if conn:
            execute_query(conn)
        else:
            with self._engine.connect() as new_conn:
                execute_query(new_conn)

        return groups

    def update_closure_on_membership_add(
        self,
        subject_type: str,
        subject_id: str,
        group_type: str,
        group_id: str,
        zone_id: str,
        conn: "Connection | None" = None,
    ) -> int:
        """Update transitive closure when a membership is added.

        When member M is added to group G:
        1. Add direct entry: M -> G (depth=1)
        2. For each group P that G belongs to: Add M -> P (depth = G->P depth + 1)
        3. If M is a group, for each member X of M: Add X -> G and X -> all ancestors of G

        Args:
            subject_type: Type of subject being added (member)
            subject_id: ID of subject being added
            group_type: Type of group receiving the member
            group_id: ID of group receiving the member
            zone_id: Zone ID
            conn: Optional existing database connection

        Returns:
            Number of closure entries created/updated
        """
        from sqlalchemy import text

        entries_added = 0

        def do_update(connection: "Connection") -> int:
            nonlocal entries_added

            # 1. Get all ancestors of the target group (including the group itself)
            ancestors_query = text("""
                SELECT group_type, group_id, depth
                FROM rebac_group_closure
                WHERE member_type = :group_type
                  AND member_id = :group_id
                  AND zone_id = :zone_id
            """)
            ancestors_result = connection.execute(
                ancestors_query,
                {"group_type": group_type, "group_id": group_id, "zone_id": zone_id},
            )
            ancestors = [(row.group_type, row.group_id, row.depth) for row in ancestors_result]

            # 2. Get all descendants of the subject (if it's a group)
            # This includes the subject itself
            descendants: list[tuple[str, str, int]] = [(subject_type, subject_id, 0)]

            if subject_type in GROUP_ENTITY_TYPES:
                descendants_query = text("""
                    SELECT member_type, member_id, depth
                    FROM rebac_group_closure
                    WHERE group_type = :subject_type
                      AND group_id = :subject_id
                      AND zone_id = :zone_id
                """)
                desc_result = connection.execute(
                    descendants_query,
                    {
                        "subject_type": subject_type,
                        "subject_id": subject_id,
                        "zone_id": zone_id,
                    },
                )
                descendants.extend(
                    [(row.member_type, row.member_id, row.depth) for row in desc_result]
                )

            # 3. For each descendant, add closure entries to target group and all its ancestors
            entries_to_add: list[dict[str, Any]] = []

            for desc_type, desc_id, desc_depth in descendants:
                # Add entry to the direct target group
                entries_to_add.append(
                    {
                        "member_type": desc_type,
                        "member_id": desc_id,
                        "group_type": group_type,
                        "group_id": group_id,
                        "zone_id": zone_id,
                        "depth": desc_depth + 1,
                    }
                )

                # Add entries to all ancestors of the target group
                for anc_type, anc_id, anc_depth in ancestors:
                    entries_to_add.append(
                        {
                            "member_type": desc_type,
                            "member_id": desc_id,
                            "group_type": anc_type,
                            "group_id": anc_id,
                            "zone_id": zone_id,
                            "depth": desc_depth + anc_depth + 1,
                        }
                    )

            # 4. Bulk upsert entries
            if entries_to_add:
                entries_added = self._bulk_upsert_closure(connection, entries_to_add)

            return entries_added

        if conn:
            return do_update(conn)
        else:
            with self._engine.begin() as new_conn:
                return do_update(new_conn)

    def update_closure_on_membership_remove(
        self,
        subject_type: str,
        subject_id: str,
        group_type: str,
        group_id: str,
        zone_id: str,
        conn: "Connection | None" = None,
    ) -> int:
        """Update transitive closure when a membership is removed.

        This is more complex than add - we need to recompute affected entries
        because the member might still have other paths to the same groups.

        For now, we use a conservative approach: invalidate and recompute.

        Args:
            subject_type: Type of subject being removed
            subject_id: ID of subject being removed
            group_type: Type of group losing the member
            group_id: ID of group losing the member
            zone_id: Zone ID
            conn: Optional existing database connection

        Returns:
            Number of closure entries removed
        """
        from sqlalchemy import text

        entries_removed = 0

        def do_update(connection: "Connection") -> int:
            nonlocal entries_removed

            # Invalidate cache for the group that lost a member
            if self._cache:
                self._cache.invalidate_group(group_type, group_id, zone_id)

            # Get all descendants of the subject (including itself)
            descendants: list[tuple[str, str]] = [(subject_type, subject_id)]

            if subject_type in GROUP_ENTITY_TYPES:
                descendants_query = text("""
                    SELECT member_type, member_id
                    FROM rebac_group_closure
                    WHERE group_type = :subject_type
                      AND group_id = :subject_id
                      AND zone_id = :zone_id
                """)
                desc_result = connection.execute(
                    descendants_query,
                    {
                        "subject_type": subject_type,
                        "subject_id": subject_id,
                        "zone_id": zone_id,
                    },
                )
                descendants.extend([(row.member_type, row.member_id) for row in desc_result])

            # For each descendant, recompute their closure
            for desc_type, desc_id in descendants:
                removed = self._recompute_member_closure(connection, desc_type, desc_id, zone_id)
                entries_removed += removed

            return entries_removed

        if conn:
            return do_update(conn)
        else:
            with self._engine.begin() as new_conn:
                return do_update(new_conn)

    def _recompute_member_closure(
        self,
        conn: "Connection",
        member_type: str,
        member_id: str,
        zone_id: str,
    ) -> int:
        """Recompute transitive closure for a single member.

        Deletes existing entries and recomputes from source tuples.

        Args:
            conn: Database connection
            member_type: Type of member
            member_id: ID of member
            zone_id: Zone ID

        Returns:
            Number of entries that were removed (negative) or added (positive)
        """
        from sqlalchemy import text

        # 1. Delete existing closure entries for this member
        delete_query = text("""
            DELETE FROM rebac_group_closure
            WHERE member_type = :member_type
              AND member_id = :member_id
              AND zone_id = :zone_id
        """)
        result = conn.execute(
            delete_query,
            {"member_type": member_type, "member_id": member_id, "zone_id": zone_id},
        )
        old_count = result.rowcount

        # 2. Find direct memberships from rebac_tuples
        direct_query = text(f"""
            SELECT object_type, object_id
            FROM rebac_tuples
            WHERE subject_type = :member_type
              AND subject_id = :member_id
              AND relation IN ('member-of', 'member', 'belongs-to')
              AND zone_id = :zone_id
              AND (expires_at IS NULL OR expires_at > {self._now_sql})
        """)
        direct_result = conn.execute(
            direct_query,
            {"member_type": member_type, "member_id": member_id, "zone_id": zone_id},
        )
        direct_groups = [(row.object_type, row.object_id) for row in direct_result]

        # 3. For each direct group, compute transitive closure using BFS
        entries: list[dict[str, Any]] = []
        visited: set[tuple[str, str]] = set()

        def bfs_groups(start_groups: list[tuple[str, str]], start_depth: int) -> None:
            queue = [(g_type, g_id, start_depth) for g_type, g_id in start_groups]

            while queue:
                g_type, g_id, depth = queue.pop(0)
                if (g_type, g_id) in visited:
                    continue
                visited.add((g_type, g_id))

                entries.append(
                    {
                        "member_type": member_type,
                        "member_id": member_id,
                        "group_type": g_type,
                        "group_id": g_id,
                        "zone_id": zone_id,
                        "depth": depth,
                    }
                )

                # Find parent groups
                now_sql = self._now_sql
                parent_query = text(f"""
                    SELECT object_type, object_id
                    FROM rebac_tuples
                    WHERE subject_type = :g_type
                      AND subject_id = :g_id
                      AND relation IN ('member-of', 'member', 'belongs-to')
                      AND zone_id = :zone_id
                      AND (expires_at IS NULL OR expires_at > {now_sql})
                """)
                parent_result = conn.execute(
                    parent_query,
                    {"g_type": g_type, "g_id": g_id, "zone_id": zone_id},
                )
                for row in parent_result:
                    if (row.object_type, row.object_id) not in visited:
                        queue.append((row.object_type, row.object_id, depth + 1))

        bfs_groups(direct_groups, 1)

        # 4. Bulk insert new entries
        if entries:
            self._bulk_upsert_closure(conn, entries)

        # Invalidate cache for this member
        if self._cache:
            self._cache.invalidate_member(member_type, member_id, zone_id)

        return len(entries) - old_count

    def _bulk_upsert_closure(
        self,
        conn: "Connection",
        entries: list[dict[str, Any]],
    ) -> int:
        """Bulk upsert closure entries.

        Args:
            conn: Database connection
            entries: List of entry dicts with member_type, member_id, group_type, group_id, zone_id, depth

        Returns:
            Number of entries affected
        """
        from sqlalchemy import text

        if not entries:
            return 0

        if self._is_postgresql:
            # PostgreSQL: Use ON CONFLICT DO UPDATE
            query = text("""
                INSERT INTO rebac_group_closure
                    (member_type, member_id, group_type, group_id, zone_id, depth, updated_at)
                VALUES
                    (:member_type, :member_id, :group_type, :group_id, :zone_id, :depth, NOW())
                ON CONFLICT (member_type, member_id, group_type, group_id, zone_id)
                DO UPDATE SET depth = EXCLUDED.depth, updated_at = NOW()
            """)
        else:
            # SQLite: Use INSERT OR REPLACE
            query = text("""
                INSERT OR REPLACE INTO rebac_group_closure
                    (member_type, member_id, group_type, group_id, zone_id, depth, updated_at)
                VALUES
                    (:member_type, :member_id, :group_type, :group_id, :zone_id, :depth, datetime('now'))
            """)

        count = 0
        for entry in entries:
            conn.execute(query, entry)
            count += 1

        return count

    def rebuild_closure_for_zone(self, zone_id: str, conn: "Connection | None" = None) -> int:
        """Rebuild entire closure table for a zone.

        Useful for:
        - Initial migration
        - Recovering from inconsistency
        - Periodic verification

        Args:
            zone_id: Zone ID
            conn: Optional database connection

        Returns:
            Number of closure entries created
        """
        from sqlalchemy import text

        now_sql = self._now_sql

        def do_rebuild(connection: "Connection") -> int:
            # 1. Delete all existing closure entries for zone
            delete_query = text("""
                DELETE FROM rebac_group_closure
                WHERE zone_id = :zone_id
            """)
            connection.execute(delete_query, {"zone_id": zone_id})

            # 2. Get all membership tuples for zone
            tuples_query = text(f"""
                SELECT subject_type, subject_id, object_type, object_id
                FROM rebac_tuples
                WHERE relation IN ('member-of', 'member', 'belongs-to')
                  AND zone_id = :zone_id
                  AND (expires_at IS NULL OR expires_at > {now_sql})
            """)
            result = connection.execute(tuples_query, {"zone_id": zone_id})
            tuples = [
                (row.subject_type, row.subject_id, row.object_type, row.object_id) for row in result
            ]

            # 3. Build closure using Floyd-Warshall-style approach
            # First, add all direct memberships
            entries: list[dict[str, Any]] = []
            for subj_type, subj_id, obj_type, obj_id in tuples:
                entries.append(
                    {
                        "member_type": subj_type,
                        "member_id": subj_id,
                        "group_type": obj_type,
                        "group_id": obj_id,
                        "zone_id": zone_id,
                        "depth": 1,
                    }
                )

            # 4. Compute transitive closure
            # Build adjacency list
            member_to_direct_groups: dict[tuple[str, str], set[tuple[str, str]]] = defaultdict(set)
            for subj_type, subj_id, obj_type, obj_id in tuples:
                member_to_direct_groups[(subj_type, subj_id)].add((obj_type, obj_id))

            # For each member, compute all transitive groups
            all_members = set(member_to_direct_groups.keys())
            for member in all_members:
                visited: set[tuple[str, str]] = set()
                queue = list(member_to_direct_groups[member])
                depth_map: dict[tuple[str, str], int] = dict.fromkeys(queue, 1)

                while queue:
                    group = queue.pop(0)
                    if group in visited:
                        continue
                    visited.add(group)

                    # Find groups this group belongs to
                    parent_groups = member_to_direct_groups.get(group, set())
                    for parent in parent_groups:
                        if parent not in visited:
                            new_depth = depth_map[group] + 1
                            if parent not in depth_map or depth_map[parent] > new_depth:
                                depth_map[parent] = new_depth
                            queue.append(parent)

                # Add transitive entries (skip depth=1, already added)
                for group, depth in depth_map.items():
                    if depth > 1:
                        entries.append(
                            {
                                "member_type": member[0],
                                "member_id": member[1],
                                "group_type": group[0],
                                "group_id": group[1],
                                "zone_id": zone_id,
                                "depth": depth,
                            }
                        )

            # 5. Bulk insert
            if entries:
                self._bulk_upsert_closure(connection, entries)

            # 6. Clear cache for zone
            if self._cache:
                self._cache.invalidate_zone(zone_id)

            return len(entries)

        if conn:
            return do_rebuild(conn)
        else:
            with self._engine.begin() as new_conn:
                return do_rebuild(new_conn)

    def invalidate_cache_for_member(self, member_type: str, member_id: str, zone_id: str) -> None:
        """Invalidate in-memory cache for a member."""
        if self._cache:
            self._cache.invalidate_member(member_type, member_id, zone_id)

    def invalidate_cache_for_group(self, group_type: str, group_id: str, zone_id: str) -> None:
        """Invalidate in-memory cache for all members of a group."""
        if self._cache:
            self._cache.invalidate_group(group_type, group_id, zone_id)

    def invalidate_cache_for_zone(self, zone_id: str) -> None:
        """Invalidate in-memory cache for a zone."""
        if self._cache:
            self._cache.invalidate_zone(zone_id)

    def clear_cache(self) -> None:
        """Clear entire in-memory cache."""
        if self._cache:
            self._cache.clear()
